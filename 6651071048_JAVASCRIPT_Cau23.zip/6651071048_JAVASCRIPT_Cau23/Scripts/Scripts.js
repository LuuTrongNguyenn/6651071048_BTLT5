function tinhLuong() {
    // Lấy giá trị Lương và Hệ số lương từ ô input
    const luong = parseFloat(document.getElementById("luong").value);
    const heSo = parseFloat(document.getElementById("heSo").value);

    // Kiểm tra tính hợp lệ
    if (isNaN(luong) || isNaN(heSo)) {
        alert("Vui lòng nhập đầy đủ Lương và Hệ số lương!");
        return;
    }

    // Tính Lương tháng = Lương * Hệ số lương
    const luongThang = luong * heSo;

    // Gán kết quả vào ô Lương tháng
    document.getElementById("luongThang").value = luongThang;
}