function xuatThu() {
    // Lấy giá trị ngày, tháng, năm từ giao diện
    const ngay = parseInt(document.getElementById("ngay").value);
    const thang = parseInt(document.getElementById("thang").value);
    const nam = parseInt(document.getElementById("nam").value);

    // Kiểm tra đầu vào hợp lệ
    if (isNaN(ngay) || isNaN(thang) || isNaN(nam)) {
        document.getElementById("ketQua").innerText = "Vui lòng nhập đầy đủ ngày, tháng, năm!";
        return;
    }

    // Tạo đối tượng Date (Lưu ý: Tháng trong JavaScript tính từ 0 đến 11)
    const d = new Date(nam, thang - 1, ngay);

    // Mảng lưu danh sách tên thứ trong tuần
    const dsThu = ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];

    // Lấy thứ từ phương thức getDay()
    const thu = dsThu[d.getDay()];

    // Xuất kết quả ra giao diện theo mẫu
    document.getElementById("ketQua").innerText = `${thu} Ngày ${ngay} tháng ${thang} năm ${nam}`;
}