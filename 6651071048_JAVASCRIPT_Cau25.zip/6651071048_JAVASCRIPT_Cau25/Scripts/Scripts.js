function tinhTien() {
    let tongTien = 0;
    let htmlKetQua = "";

    // 1. Lấy danh sách thức ăn được chọn
    const selectThucAn = document.getElementById("thucAn");
    for (let option of selectThucAn.selectedOptions) {
        const gia = parseFloat(option.value);
        const tenMon = option.text;
        tongTien += gia;
        htmlKetQua += `<tr><td>${tenMon}</td><td>${gia}</td></tr>`;
    }

    // 2. Lấy danh sách nước uống được chọn
    const selectNuocUong = document.getElementById("nuocUong");
    for (let option of selectNuocUong.selectedOptions) {
        const gia = parseFloat(option.value);
        const tenMon = option.text;
        tongTien += gia;
        htmlKetQua += `<tr><td>${tenMon}</td><td>${gia}</td></tr>`;
    }

    // 3. Kiểm tra thời điểm (Ban đêm tăng 10%)
    const banDem = document.getElementById("banDem").checked;
    if (banDem) {
        tongTien = tongTien * 1.1; // Tăng 10%
    }

    // 4. Thêm dòng Tổng tiền vào bảng
    htmlKetQua += `<tr><td><b>Tổng tiền</b></td><td><b>${tongTien} đồng</b></td></tr>`;

    // 5. Hiển thị danh sách và tổng tiền ra giao diện
    document.getElementById("dsMonDaDung").innerHTML = htmlKetQua;
}