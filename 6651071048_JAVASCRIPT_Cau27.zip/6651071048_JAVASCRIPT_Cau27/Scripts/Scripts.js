function xoaDong(btn) {
    // btn chính là nút "Xóa" được bấm
    // btn.parentElement là ô <td> chứa nút đó
    // btn.parentElement.parentElement chính là thẻ <tr> (dòng chứa nút đó)
    const dong = btn.parentElement.parentElement;
    
    // Xóa dòng đó khỏi bảng
    dong.remove();
}