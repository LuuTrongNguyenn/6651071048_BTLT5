function tinhCanChi() {
    const namInput = document.getElementById("namDuongLinh").value.trim();

    // 1. Kiểm tra validate: Không được để trống và phải là số nguyên dương
    if (namInput === "" || isNaN(namInput) || parseInt(namInput) <= 0) {
        alert("Vui lòng nhập năm dương lịch hợp lệ (là số nguyên dương)!");
        document.getElementById("canChiAmLich").value = "";
        return;
    }

    const nam = parseInt(namInput);

    // 2. Mảng chứa 10 Can và 12 Chi
    // Công thức tính Can: (Năm - 4) % 10
    const dsCan = ["Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"];

    // Công thức tính Chi: (Năm - 4) % 12
    const dsChi = ["Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"];

    // 3. Tính chỉ số Can và Chi
    const canIndex = (nam - 4) % 10;
    const chiIndex = (nam - 4) % 12;

    // Xử lý trường hợp số âm nếu nhập năm quá khứ xa
    const can = dsCan[(canIndex + 10) % 10];
    const chi = dsChi[(chiIndex + 12) % 12];

    // 4. Xuất kết quả ra ô Can chi năm âm lịch
    document.getElementById("canChiAmLich").value = `${can} ${chi}`;
}